﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using JR_Consulting_Version_1._1.Controlador;
using System.Data;
using System.Windows.Forms;

namespace JR_Consulting_Version_1._1.Modelo
{
    public class Nominas
    {
        public int IdNomina { get; set; }
        public string Servicio_Nomina { get; set; }
        public string Num_Empleados { get; set; }
        public string Frecu_Pago { get; set; }
        Usuario2 obj2 = new Usuario2(); //from metodo
        public Nominas()
        {
            Servicio_Nomina = "";
            Num_Empleados = "";
            Frecu_Pago = "";
        }

        public Nominas(string s, string e, string p)
        {
            Servicio_Nomina = s;
            Num_Empleados = e;
            Frecu_Pago = p;
        }
        public int Guardar()
        {
            string consulta = "insert into Nominas values('" + Servicio_Nomina + "','" + Num_Empleados + "','" + Frecu_Pago + "')";

            int res = obj2.Guardar(consulta);
            return res;
        }

    }
    public class Empresa
    {
        public int IdEmpresa { get; set; }
        public Nominas IdNomina { get; set; }
        public string Facturas_Mes { get; set; }
        public string Cheques { get; set; }
        public string Activos { get; set; }
        public string Sucursales { get; set; }

        public Empresa()
        {
            IdNomina = null;
            Facturas_Mes = "";
            Cheques = "";
            Activos = "";
            Sucursales = "";
        }

        public Empresa(Nominas n,string f, string c, string a, string s)
        {
            IdNomina = n; 
            Facturas_Mes = f;
            Cheques = c;
            Activos = a;
            Sucursales = s;
        }

        public int altaEmpresa()
        {
            Nominas obj = new Nominas();
            SqlCommand Comando;
            Datos inserta = new Datos();
            int regresa = 0;
            if (inserta.Conectar())
            {
                String comando = "Insert into Empresa(Facturas_Mes, Cheques, Activos, Sucursales)" +
                    "values('" + Facturas_Mes + "','" + Cheques + "','" + Activos + "','" + Sucursales + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

    }

    public class Datos_Personales
    {
        public int IdPersona { get; set; }
        public int IdEmpresa { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string Telefono { get; set; }
        public string Regimen_Fiscal { get; set; }
        public string Estado { get; set; }


        public Datos_Personales()
        {
            IdEmpresa = 0;
            Nombre = "";
            Correo = "";
            Telefono = "";
            Regimen_Fiscal = "";
            Estado = "";
        }

        public Datos_Personales(string n, string c, string t, string r, string e, int E)
        {
            IdEmpresa = E;
            Nombre = n;
            Correo = c;
            Telefono = t;
            Regimen_Fiscal = r;
            Estado = e;
        }

        public int altaDatos()
        {

            SqlCommand Comando;
            Datos inserta = new Datos();
            int regresa = 0;
            if (inserta.Conectar())
            {
                String comando = "Insert into Datos_Personales(Nombre, Correo, Telefono, Regimen_Fiscal, Estado)" +
                    "values('" + Nombre + "','" + Correo + "','" + Telefono + "','" + Regimen_Fiscal + "','" + Estado + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int BusquedaFondo(System.Web.UI.WebControls.TextBox eti, System.Web.UI.WebControls.TextBox eti2, System.Web.UI.WebControls.TextBox eti3, System.Web.UI.WebControls.TextBox eti4, System.Web.UI.WebControls.TextBox eti5, System.Web.UI.WebControls.TextBox txtFondo)
        {
            SqlDataAdapter adaptador;
            DataRow fila;
            Datos selecciona = new Datos();
            if (selecciona.Conectar())
            {
                adaptador = selecciona.construye_adapter("Execute  BusquedaPersona '" + txtFondo.Text + "'");
                fila = selecciona.extrae_registro(adaptador, "Datos_Personales");
                if (fila != null)
                {
                    eti.Text = fila["Nombre"].ToString();
                    eti2.Text = fila["Correo"].ToString();
                    eti3.Text = fila["Telefono"].ToString();
                    eti4.Text = fila["Estado"].ToString();
                    eti5.Text = fila["Regimen_Fiscal"].ToString();
                }
                return 1;
            }
            else
                return 1;

        }
    }
    }
   

