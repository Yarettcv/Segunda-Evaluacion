﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace JR_Consulting_Version_1._1.Vista
{
    public partial class Ingresar : System.Web.UI.Page
    {
        SqlConnection Con = new SqlConnection("Data source = localhost; Initial catalog= Consultoria; Integrated security=true");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            inicioSesion(this.txtUsuario.Text, this.txtContraseña.Text);
        }
        public void inicioSesion (String Usuario, String Contraseña)
        {
            try
            {
                Con.Open();
                SqlCommand comando = new SqlCommand("select Nom_Usuario, Contraseña from Usuario where Nom_Usuario = '" + txtUsuario.Text + "'And Contraseña = '" + txtContraseña.Text + "' ", Con);
                SqlDataAdapter da = new SqlDataAdapter(comando);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 1)
                {
                    Response.Redirect("Sistema.aspx");
                }
                else {
                    MessageBox.Show("Usuario y/o contraseña incorrecta!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            /*catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            */
            finally
            {
                Con.Close();
            }
            
        }


        protected void txtUsuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

