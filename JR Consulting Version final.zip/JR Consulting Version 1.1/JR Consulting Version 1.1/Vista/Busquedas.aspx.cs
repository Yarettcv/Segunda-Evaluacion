﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using JR_Consulting_Version_1._1.Modelo;

namespace JR_Consulting_Version_1._1.Vista
{
    public partial class Busquedas : System.Web.UI.Page
    {
        Datos_Personales obj = new Datos_Personales();
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnBuscarFondo_Click(object sender, EventArgs e)
        {
            if (Txtidfondo.Text == "")
            {
                MessageBox.Show("Llene el campo idFondo", "Busqueda de idFondo", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                Txtidfondo.Focus();
            }
            else
            {


                // TxtObservaciones_fondo.Text = Seguridad.DesEncriptar(TxtObservaciones_fondo.Text);

                obj.BusquedaFondo(Txtnombre_fondo,
                                   txtCorreo,
                                   txtTelefono,
                                   txtEstado,
                                   txtRegimen,
                                   Txtidfondo);

                //Txtnombre_fondo.Text = Seguridad.DesEncriptar(Txtnombre_fondo.Text);
                //TxtDireccion_fondo.Text = Seguridad.DesEncriptar(TxtDireccion_fondo.Text);
                //TxtObservaciones_fondo.Text = Seguridad.DesEncriptar(TxtObservaciones_fondo.Text);


            }
            MessageBox.Show("Finalizo la Busqueda!", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
    }
    }
