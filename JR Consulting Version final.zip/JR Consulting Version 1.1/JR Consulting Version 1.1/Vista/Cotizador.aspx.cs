﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using JR_Consulting_Version_1._1.Modelo;
using JR_Consulting_Version_1._1.Controlador;
using System.Data.SqlClient;
using System.Data;

namespace JR_Consulting_Version_1._1.Vista
{
    public partial class Cotizador : System.Web.UI.Page
    {
        Datos_Personales obj = new Datos_Personales();
        Empresa obj1 = new Empresa();
        Nominas obj2 = new Nominas();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtbAgregar_Click(object sender, EventArgs e)
        {
            if (TxtNombre.Text == "" || TxtCorreo.Text == "" || TxtTelefono.Text == "")
            {
                MessageBox.Show("Ingrese los datos completos", "Cotizador", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
            else
            {
                obj2.Servicio_Nomina = dplServicios.Text;
                obj2.Num_Empleados = dplSeguro.Text;
                obj2.Frecu_Pago = dplPago.Text;
                int r = obj2.Guardar();

                obj1.Facturas_Mes = dplFacturas.Text;
                obj1.Cheques = dplCheques.Text;
                obj1.Activos = dplCheques.Text;
                obj1.Sucursales = dplsucursales.Text;
                int m = obj1.altaEmpresa();
                

                obj.Nombre = TxtNombre.Text;
                obj.Correo = TxtCorreo.Text;
                obj.Telefono = TxtTelefono.Text;
                obj.Regimen_Fiscal = dplRegimen.Text;
                obj.Estado = dplEstado.Text;
  
                int s = obj.altaDatos();
                
                if (r == 1 && m==1 && s==1)
                {
                    MessageBox.Show("Tus datos fueron enviados en breve personal del despacho JR Consulting, se pondrá en contacto con Ud.");
                }
                else if (r == 0)
                {
                    MessageBox.Show("No se enviaron los datos");
                }
                else
                {
                    MessageBox.Show("Error con la base de datos");
                }
                TxtNombre.Text = "";
                TxtCorreo.Text = "";
                TxtTelefono.Text="";
                dplEstado.Text = "Selecciona";
                dplRegimen.Text = "Selecciona";
                dplFacturas.Text = "Selecciona";
                dplCheques.Text = "Selecciona";
                dplActivos.Text = "Selecciona";
                dplsucursales.Text = "Selecciona";
                dplServicios.Text = "Selecciona";
                dplSeguro.Text = "Selecciona";
                dplPago.Text = "Selecciona";
            }
        }
    }
}