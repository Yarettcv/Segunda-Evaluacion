﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JR_Consulting_Version_1._1.Controlador
{
    public class Servidor
    {
        public string Svractual { get; set; }
        public string Bdatos { get; set; }
        public string MyQuery { get; set; }
        public string MyCadCon { get; set; }

        public Servidor(string Svractual, string Bdatos)
        {
            this.Svractual = Svractual;
            this.Bdatos = Bdatos;
        }
    }
}