﻿using ctrlArchivos.Modelo;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace ctrlArchivos.Modelo
{
    public class Edificio
    {
        public string id_fondo { get; set; }

        public string nombre_fondo { get; set; }

        public string Direccion_fondo { get; set; }

        public string observaciones { get; set; }


        public Edificio()
        {
            id_fondo = "";
            nombre_fondo = "";
            Direccion_fondo = "";
            observaciones = "";
        }
        public Edificio(string fon, string nom, string dire, string obs)
        {
            id_fondo = fon;
            nombre_fondo = nom;
            Direccion_fondo = dire;
            observaciones = obs;
        }
        public int altafondo()
        {
            SqlCommand Comando;
            Datos inserta = new Datos();
            int regresa = 0;
            if (inserta.Conectar())
            {
                String comando = "Insert into fondo(id_fondo,nombre_fondo,direccion_fondo, observaciones)" +
                    "values('" + id_fondo + "','" + nombre_fondo + "','" + Direccion_fondo + "','" + observaciones + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int bajafondo(String baja)
        {
            SqlCommand Comando;
            Datos eliminar = new Datos();
            int regresa = 0;
            if (eliminar.Conectar())
            {
                String comando = "delete from fondo where id_fondo='" + baja + "'";
                Comando = eliminar.construye_command(comando);
                if ((eliminar.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                eliminar.desconectar();
            }
            else { regresa = -1; }
            return regresa;
        }

        public int actualizar_fondo(string idfondo)
        {
            SqlCommand Comando;
            Datos inserta = new Datos();
            int regresa = 0;
            if (inserta.Conectar())
            {
                String comando = "exec ActulizaFondo   '" + id_fondo + "','" + nombre_fondo + "','" + Direccion_fondo + "','" + observaciones + "'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                {
                    regresa = 1;
                }
                else
                {
                    regresa = 0;
                }
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
            {
                regresa = -1;
            }
            return regresa;

        }
        public int BusquedaFondo(System.Web.UI.WebControls.TextBox eti, System.Web.UI.WebControls.TextBox eti2, System.Web.UI.WebControls.TextBox eti3, System.Web.UI.WebControls.TextBox txtFondo)
        {
            SqlDataAdapter adaptador;
            DataRow fila;
            Datos selecciona = new Datos();
            if (selecciona.Conectar())
            {
                adaptador = selecciona.construye_adapter("Execute  BusquedaFondo '" + txtFondo.Text + "'");
                fila = selecciona.extrae_registro(adaptador, "fondo");
                if (fila != null)
                {
                    eti.Text = fila["nombre_fondo"].ToString();
                    eti2.Text = fila["direccion_fondo"].ToString();
                    eti3.Text = fila["Observaciones"].ToString();
                }
                return 1;
            }
            else
                return 1;

        }
    }
    public class c_edeficio
    {
        public String idEdificio { get; set; }
        //   public EdificionOne prueba { get; set; }
        public String DescripcionoEd { get; set; }
        public String id_fondo { get; set; }
        // Usuario2 obj1 = new Usuario2();

        public c_edeficio()
        {
            idEdificio = "";
            DescripcionoEd = "";
            id_fondo = "";

        }
        public c_edeficio(string idef, string des, string idfon)
        {
            idEdificio = idef;
            DescripcionoEd = des;
            id_fondo = idfon;

        }
        public int Alta_Edificio()
        {
            SqlCommand Comando;
            Datos inserta = new Datos();
            int regresa = 0;
            if (inserta.Conectar())
            {
                String comando = "exec InsertaEdifico '" + idEdificio + "','" + DescripcionoEd + "','" + id_fondo + "'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                {
                    regresa = 1;
                }
                else
                {
                    regresa = 0;
                }
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
            {
                regresa = -1;
            }
            return regresa;
        }
        public int actualizar_edificio(string idedificio)
        {
            SqlCommand Comando;
            Datos inserta = new Datos();
            int regresa = 0;
            if (inserta.Conectar())
            {
                String comando = "exec ActulizarEdificio   '" + idEdificio + "','" + DescripcionoEd + "','" + id_fondo + "'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                {
                    regresa = 1;
                }
                else
                {
                    regresa = 0;
                }
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
            {
                regresa = -1;
            }
            return regresa;

        }
        public int Carga_idfondo(DropDownList cmb)
        {
            Datos cargarfondo = new Datos();
            SqlDataReader lector;
            if (cargarfondo.Conectar())
            {
                cargarfondo.construye_reader("select *from fondo");
                lector = cargarfondo.ejecuta_reader();
                while (lector.Read())
                    cmb.Items.Add(lector.GetString(1).ToString());
                cargarfondo.desconectar();
                cargarfondo.dr.Close();
                return 1;
            }
            else
                return -1;
        }

        public int RegresaIdfondo(System.Web.UI.WebControls.DropDownList carga)
        {
            SqlDataAdapter adaptador;
            DataRow fila;
            //SqlCommand Comando;
            Datos regresar = new Datos();
            //int regresa = 0;
            if (regresar.Conectar())
            {

                adaptador = regresar.construye_adapter("execute cargarIDfondo " + carga.Text + "");
                fila = regresar.extrae_registro(adaptador, "fondo");
                if (fila != null)
                {
                    carga.Text = fila["id_fondo"].ToString();
                }
                return 1;
            }
            else
                return 1;
        }

        public int baja_Edeficio(String baja)
        {
            SqlCommand Comando;
            Datos eliminar = new Datos();
            int regresa = 0;
            if (eliminar.Conectar())
            {
                String comando = "delete from edificio where IdEdificio='" + baja + "'";
                Comando = eliminar.construye_command(comando);
                if ((eliminar.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                eliminar.desconectar();
            }
            else { regresa = -1; }
            return regresa;
        }
    }
}
            public class Pisoo
            {
                public String IdPisoEd { get; set; }
                public String DescripcionPiso { get; set; }
                public String IdEdificio { get; set; }


                public Pisoo()
                {
                    IdPisoEd = "";
                    DescripcionPiso = "";
                    IdEdificio = "";
                }

                public Pisoo(string a, string b, string c)
                {
                    IdPisoEd = a;
                    DescripcionPiso = b;
                    IdEdificio = c;
                }

                public int alta_Piso()
                {
                    SqlCommand Comando;
                    Datos inserta = new Datos();
                    int regresa = 0;
                    if (inserta.Conectar())
                    {
                        String comando = "Insert into Piso(IdPisoEd, DescripcionPiso, IdEdificio)" +
                            "values('" + IdEdificio + "','" + DescripcionPiso + "','" + IdEdificio + "')";
                        Comando = inserta.construye_command(comando);
                        if ((inserta.ejecutanonquery()) != 0)
                            regresa = 1;
                        else
                            regresa = 0;
                        Comando.Connection.Close();
                        inserta.desconectar();
                    }
                    else
                        regresa = -1;
                    return regresa;
                }

                public int baja_Piso(String baja)
                {
                    SqlCommand Comando;
                    Datos eliminar = new Datos();
                    int regresa = 0;
                    if (eliminar.Conectar())
                    {
                        String comando = "delete from Piso where IdPisoEd='" + baja + "'";
                        Comando = eliminar.construye_command(comando);
                        if ((eliminar.ejecutanonquery()) != 0)
                            regresa = 1;
                        else
                            regresa = 0;
                        Comando.Connection.Close();
                        eliminar.desconectar();
                    }
                    else { regresa = -1; }
                    return regresa;
                }
    public int actualizar_piso(string idPsio)
    {
        SqlCommand Comando;
        Datos inserta = new Datos();
        int regresa = 0;
        if (inserta.Conectar())
        {
            String comando = "exec ActulizaPsio  '" + IdPisoEd + "','" + DescripcionPiso + "','" + IdEdificio + "'";
            Comando = inserta.construye_command(comando);
            if ((inserta.ejecutanonquery()) != 0)
            {
                regresa = 1;
            }
            else
            {
                regresa = 0;
            }
            Comando.Connection.Close();
            inserta.desconectar();
        }
        else
        {
            regresa = -1;
        }
        return regresa;

    }
}

        

    
