﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using ctrlArchivos.Modelo;
using System.Data.SqlClient;

namespace ctrlArchivos.Modelo
{
    public class Documento
    {
        public String clasificacion_exp { get; set; }
        public String id_doc { get; set; }
        public String tipo_doc { get; set; }
        public String estatus_docu { get; set; }
        public String prioridad_doc { get; set; }
        public String id_remitente_doc { get; set; }
        public String no_doc { get; set; }
        public DateTime fecha_docu { get; set; }
        public String id_Destinatario { get; set; }
        public DateTime fecha_rec_doc { get; set; }
        public DateTime hora_rese_doc { get; set; }
        public String asunto { get; set; }
        public String obs_doc { get; set; }
        public String des_anexo_doc { get; set; }
        public int no_fajos_doc { get; set; }
        public String id_delegado_doc { get; set; }
        public String status_dele_doc { get; set; }
        public DateTime fecha_dele_doc { get; set; }

        Usuario2 obj2 = new Usuario2(); //from metodo
        
        public void cargarDatosIniciales
            (
            DropDownList ddl_Clasi
            )
        {
            string consulta = "";

            consulta = "select clasificacion_exp from expediente";
            obj2.cargar_DropDownListString(ddl_Clasi, consulta);

        }
        public int Guardar()
        {
            string consulta = "insert into documento values('"+ clasificacion_exp + "', '" + 
                id_doc + "', '" + tipo_doc + "', '" + estatus_docu + "', '" + prioridad_doc + "','" + id_remitente_doc + "','" +
                no_doc + "', '" + Convert.ToDateTime(fecha_docu).ToShortDateString() + "', '" + id_Destinatario + "', '" +
                Convert.ToDateTime(fecha_rec_doc).ToShortDateString() + "', '" + hora_rese_doc.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "', '" + asunto + "','" + obs_doc + "', '" + 
                des_anexo_doc + "', '" + no_fajos_doc + "', '" + id_delegado_doc + "', '" + status_dele_doc + "', '" +
                Convert.ToDateTime(fecha_dele_doc).ToShortDateString() + "')";

            int res = obj2.Guardar(consulta);
            return res;
        }
        public int Actualizar()
        {
            string consulta = ("update documento set clasificacion_exp='" + clasificacion_exp+ "',tipo_doc='" + tipo_doc + "',estatus_doc='" + estatus_docu +
                "',prioridad_doc='" + prioridad_doc + "',id_remitente_doc='" + id_remitente_doc + "',no_doc='" + no_doc + "',fecha_doc='" + Convert.ToDateTime(fecha_docu).ToShortDateString() + "',id_destinatario='" + id_Destinatario +
                "',fecha_recep_doc='" + Convert.ToDateTime(fecha_rec_doc).ToShortDateString() + "',hora_recep_doc='" + hora_rese_doc.ToString("yyyy-MM-ddTHH:mm:ss.fff") + "',asunto='" + asunto  +"',obs_doc='" + obs_doc  + "',desc_anexos_doc='" + des_anexo_doc +
                "',no_fojas_doc='" + no_fajos_doc + "',id_delegado_doc='" + id_delegado_doc + "',estatus_dele_doc='" + estatus_docu + "',fecha_dele_doc='" + Convert.ToDateTime(fecha_dele_doc).ToShortDateString() + "' where id_doc=" + id_doc);

            int res = obj2.Guardar(consulta);
            return res;
        }
        public int Eliminar(String id_documento)
        {
            String consulta = "DELETE FROM documento WHERE id_doc='" + id_documento + "';";
            int res = obj2.Guardar(consulta);
            return res;
        }
        /*public Documento BuscarDoc(String Consulta, Documento MiExp)//buscando documento
        {
            Datos selecciona = new Datos();
            SqlDataReader lector;

            if (selecciona.Conectar())
            {
                selecciona.construye_reader(Consulta);
                lector = selecciona.ejecuta_reader();

                if (lector.Read() == true)//verifica que el data reader tengan datos aunque sean null
                {
                    do
                    {
                        if (!(lector.IsDBNull(0))) //veririfca que no sean datos null
                        {
                            MiExp.clasificacion_exp = lector.GetString(0);
                            MiExp.id_doc = lector.GetString(1);
                            MiExp.tipo_doc = lector.GetString(2);
                            MiExp.estatus_docu = lector.GetString(3);
                            MiExp.prioridad_doc = lector.GetString(4);
                            MiExp.id_remitente_doc = lector.GetString(5);
                            MiExp.no_doc = lector.GetString(6);
                            MiExp.fecha_docu = lector.GetDateTime(7);
                            MiExp.id_Destinatario = lector.GetString(8);
                            MiExp.fecha_rec_doc = lector.GetDateTime(9);
                            MiExp.hora_rese_doc = lector.GetDateTime(10);
                            MiExp.asunto = lector.GetString(11);
                            MiExp.obs_doc = lector.GetString(12);
                            MiExp.des_anexo_doc = lector.GetString(13);
                            MiExp.no_fajos_doc = lector.GetInt32(14);
                            MiExp.id_delegado_doc = lector.GetString(15);
                            MiExp.estatus_docu = lector.GetString(16);
                            MiExp.fecha_dele_doc = lector.GetDateTime(10);
                        }
                    } while (lector.Read());
                    selecciona.desconectar();
                    selecciona.dr.Close();

                    return MiExp;
                }
                else
                {
                    return null;
                }

            }
            else
                return null;
        }
        */

    }

}