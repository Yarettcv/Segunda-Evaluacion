﻿function Bn() {
    alert("Bienvenido al sistema... ;)");
    window.location = "/vista/Inicio.aspx";
}

function Er() {
    alert("No estas registrado, acceso denegado :|");
    window.location = "Login.aspx";
}

function GuardarDatos() {
    alert("Datos ingresados correctamente :)");
  
}
function bn() {
    alert("Datos ingresados correctamente :)");
    window.location = "/vista/documento.aspx";
}

function ErAgregarDatos() {
    alert("No se han podido ingresar los datos del Documento :( ");
    window.location = "/vista/expediente.aspx";
}

function registroDocumento() {
    alert("Datos ingresados correctamente :)");
    window.location = "/vista/expediente.aspx";
}

function erRegistroDocumento() {
    alert("No se han podido ingresar los datos del Documento :( ");
    window.location = "/vista/expediente.aspx";
}

function registroEmpleado2() {
    alert("Registrado de Empleado correcto :-)");
    window.location = "/Login.aspx";
}

function erRegistroEmpleado2() {
    alert("No se ha podido registrar al Empleado :( ");
    window.location = "/Login.aspx";
}

function registroArchivo() {
    alert("Datos ingresados correctamente :)");
    window.location = "/vista/documento.aspx";
}

function erRegistroArchivo() {
    alert("No se ha podido registrar el Archivo :( ");
    window.location = "/vista/documento.aspx";
    }

    
function bajaArchivo() {
    alert("Se ha dado de baja del sistema :-)");
    window.location = "/View/BajaObreros.aspx";
}

function erbajaObrero() {
    alert("No se ha podido realizar la baja :( ");
    window.location = "/View/BajaObreros.aspx";
}

function bajaProducto() {
    alert("Se ha dado de baja del sistema :-)");
    window.location = "/View/BajaProducto.aspx";
}

function erbajaProducto() {
    alert("No se ha podido realizar la baja :( ");
    window.location = "/View/BajaProducto.aspx";
}

function modificacionObrero() {
    alert("Se han actualizado los datos en el sistema :-)");
    window.location = "/View/ModificarEmpleado.aspx";
}

function ermodificacionObrero() {
    alert("No se han podido actualizar los datos en el sistema :( ");
    window.location = "/View/ModificarPersona.aspx";
}

function modificacionEmpleado() {
    alert("Se han actualizado los datos en el sistema :-)");
    window.location = "/View/Inicio.aspx";
}

function ermodificacionEmpleado() {
    alert("No se han podido actualizar los datos en el sistema :( ");
    window.location = "/View/ModificarEmpleado.aspx";
}
function modificacionProducto() {
    alert("Se han actualizado los datos en el sistema :-)");
    window.location = "/View/Inicio.aspx";
}

function ermodificacionProducto() {
    alert("No se han podido actualizar los datos en el sistema :( ");
    window.location = "/View/ModificarProducto.aspx";
}

function registroProductoOb() {
    alert("Registrado de Producto correcto :-)");
    window.location = "/View/Inicio.aspx";
}

function erRegistroProductoOb() {
    alert("No se ha podido registrar el Producto :( ");
    window.location = "/View/ProductoObrero.aspx";
}

function bn2() {
    alert("¡Los campos Usuario y Contraseña son necesarios!");
    window.location = "/Login.aspx";
}

function al() {
    alert("¡Todos los campos son necesarios!");
    window.location = "/View/AltaEmpleados.aspx";
}

