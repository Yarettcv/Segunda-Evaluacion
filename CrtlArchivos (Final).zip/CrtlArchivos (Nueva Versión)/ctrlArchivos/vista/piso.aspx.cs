﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ctrlArchivos.Modelo;
using System.Windows.Forms;

namespace ctrlArchivos.vista
{
    public partial class Piso : System.Web.UI.Page
    {
        Seguridades obj2 = new Seguridades();
        Pisoo obj1 = new Pisoo();
        Datos conn = new Datos();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAgregarPiso_Click(object sender, EventArgs e)
        {
            if (TxtIdpiso.Text == "" || TxtDescrip_piso.Text == "" || TxtE_Piso.Text == "")
            {
                MessageBox.Show("Ingrese los datos completos");
            }
            else
            {
                obj1.IdPisoEd = TxtIdpiso.Text;
                //obj1.DescripcionPiso = Seguridad.Encriptar(TxtDescrip_piso.Text);
                obj1.IdEdificio = TxtE_Piso.Text;
                int r = obj1.alta_Piso();
                if (r == 1)
                {
                    MessageBox.Show("Tus registro ha finalizado correctamente.");
                }
                else if (r == 0)
                {
                    MessageBox.Show("No se realizo el registro");
                }
                else
                {
                    MessageBox.Show("Error con la base de datos");
                }
            }
        }

        protected void btnActualizarPiso_Click(object sender, EventArgs e)
        {
            /*
           if (TxtIdpiso.Text == "" || TxtDescrip_piso.Text == "" || TxtE_Piso.Text == "")
            {
                MessageBox.Show("ingrese los datos completos POR FAVOR!!!", " Actualizacion ", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
            else
            {
                obj1.IdPisoEd = TxtIdpiso.Text;
                obj1.DescripcionPiso = Seguridad.Encriptar(TxtDescrip_piso.Text);
                obj1.IdEdificio = (TxtE_Piso.Text);


                int r = obj1.actualizar_piso(TxtIdpiso.Text);
                if (r == -1)
                    MessageBox.Show("Datos Modificados", "Modificaciones", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                else
                {
                    MessageBox.Show("Actualizacion con exito", "Actualizacion", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
                }
            }
            */
            
        }

        protected void btnEliminarPiso_Click(object sender, EventArgs e)
        {
            if (TxtIdpiso.Text == "")
            {
                MessageBox.Show("Ingresa primero el ID Piso ");
            }
            else
            {
                int r = obj1.baja_Piso(TxtIdpiso.Text);
                if (r == 1)
                {
                    MessageBox.Show("Producto eliminada correctamente.");
                }
                else if (r == 0)
                {
                    MessageBox.Show("Producto NO Existe!!");
                }
                else
                {
                    MessageBox.Show("Error en la base de datos");
                }
            }
        }

        protected void btnBuscarPiso_Click(object sender, EventArgs e)
        {

        }
    }
}