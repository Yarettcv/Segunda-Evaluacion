﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ctrlArchivos.Modelo;
using System.Windows.Forms;

namespace ctrlArchivos.vista
{
    public partial class fondo : System.Web.UI.Page
    {
        Seguridades objeto2 = new Seguridades();
        Edificio obj1 = new Edificio();
        Datos conn = new Datos();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAgregarFondo_Click(object sender, EventArgs e)
        {
            if (Txtidfondo.Text == "" || Txtnombre_fondo.Text == "" || TxtDireccion_fondo.Text == "" || TxtObservaciones_fondo.Text == "")
            {
                MessageBox.Show("ingrese los datos completos POR FAVOR!!!", " Alta de FONDO ", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                Txtidfondo.Focus();
            }
            else
            {
                obj1.id_fondo = Txtidfondo.Text;
                //obj1.nombre_fondo = Seguridades.Encriptar(Txtnombre_fondo.Text);
                //obj1.Direccion_fondo = Seguridades.Encriptar(TxtDireccion_fondo.Text);
                //obj1.observaciones = Seguridades.Encriptar(TxtObservaciones_fondo.Text);

                int add = obj1.altafondo();
                //TxtDireccion_fondo.Text;
                //TxtObservaciones_fondo.Text;

                if (add == 1)
                {

                    MessageBox.Show("Datos guardados correctamente!!", "Registro de Fondo", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    Txtidfondo.Text = "";
                    Txtnombre_fondo.Text = "";
                    TxtDireccion_fondo.Text = "";
                    TxtObservaciones_fondo.Text = "";

                }
                else if (add == 0)
                    MessageBox.Show("Verificar sus datos!! ", "Erro", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                else
                {
                    MessageBox.Show("Problemas con el servidor \n Espere unos momentos", "Erro", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                }
            }
        }

        protected void btnActualizarFondo_Click(object sender, EventArgs e)
        {
            if (Txtidfondo.Text == "" || Txtnombre_fondo.Text == "" || TxtDireccion_fondo.Text == "" || TxtObservaciones_fondo.Text == "")
            {
                MessageBox.Show("ingrese los datos completos POR FAVOR!!!", " Actualizacion ", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                Txtidfondo.Focus();
            }
            else
            {
                obj1.id_fondo = Txtidfondo.Text;
                //obj1.nombre_fondo = Seguridad.Encriptar(Txtnombre_fondo.Text);
                //obj1.Direccion_fondo = Seguridad.Encriptar(TxtDireccion_fondo.Text);
                //obj1.observaciones = Seguridad.Encriptar(TxtObservaciones_fondo.Text);

                int r = obj1.actualizar_fondo(Txtidfondo.Text);
                if (r == -1)
                    MessageBox.Show("Datos Modificados", "Modificaciones", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                else
                {
                    MessageBox.Show("Actualizacion con exito", "Actualizacion", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
                }
            }
        }

        protected void btnEliminarFondo_Click(object sender, EventArgs e)
        {
            if (Txtidfondo.Text == "")
            {
                MessageBox.Show("Ingresa primero el IDFondo ");
            }
            else
            {
                int r = obj1.bajafondo(Txtidfondo.Text);
                if (r == 1)
                {
                    MessageBox.Show("Se elimino correctamente.");
                }
                else if (r == 0)
                {
                    MessageBox.Show("NO Existe!!");
                }
                else
                {
                    MessageBox.Show("Error en la base de datos");
                }
            }
        }

        protected void btnBuscarFondo_Click(object sender, EventArgs e)
        {
            if (Txtidfondo.Text == "")
            {
                MessageBox.Show("Llene el campo idFondo", "Busqueda de idFondo", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                Txtidfondo.Focus();
            }
            else
            {


               // TxtObservaciones_fondo.Text = Seguridad.DesEncriptar(TxtObservaciones_fondo.Text);

                obj1.BusquedaFondo(Txtnombre_fondo,
                                   TxtDireccion_fondo,
                                   TxtObservaciones_fondo,
                                   Txtidfondo);

                //Txtnombre_fondo.Text = Seguridad.DesEncriptar(Txtnombre_fondo.Text);
                //TxtDireccion_fondo.Text = Seguridad.DesEncriptar(TxtDireccion_fondo.Text);
                //TxtObservaciones_fondo.Text = Seguridad.DesEncriptar(TxtObservaciones_fondo.Text);


            }
            MessageBox.Show("Finalizo la Busqueda del idfondo", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Information);
        
    }
    }
}