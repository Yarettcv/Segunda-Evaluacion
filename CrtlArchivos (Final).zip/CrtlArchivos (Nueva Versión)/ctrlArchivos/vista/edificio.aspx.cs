﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ctrlArchivos.Modelo;
using System.Windows.Forms;

namespace ctrlArchivos.vista
{
    public partial class edificio : System.Web.UI.Page
    {
        Seguridades objeto2 = new Seguridades();
        c_edeficio obj1 = new c_edeficio();
        Datos conn = new Datos();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAgregarEdi_Click(object sender, EventArgs e)
        {
            if (TxtidEdificio.Text == "" || TxtDescripcionEdeficio.Text == "" || TextFONDO.Text == "")
            {
                MessageBox.Show("Ingrese los datos completos", "ALta Edificio", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
            else
            {
                obj1.idEdificio = TxtidEdificio.Text;
               // obj1.DescripcionoEd = Seguridades.Encriptar(TxtDescripcionEdeficio.Text);
                obj1.id_fondo = TextFONDO.Text;
                int r = obj1.Alta_Edificio();
                if (r == 1)
                {
                    MessageBox.Show("Tus registro ha finalizado correctamente.");
                }
                else if (r == 0)
                {
                    MessageBox.Show("No se realizo el registro");
                }
                else
                {
                    MessageBox.Show("Error con la base de datos");
                }
            }
        }

        protected void btnBuscarEdi_Click(object sender, EventArgs e)
        {
            /*
            if (TxtidEdificio.Text == "")
            {
                MessageBox.Show("Llene el campo id Edificio", "Busqueda de idEdificio", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
            else
            {


                TxtObservaciones_fondo.Text = Seguridad.DesEncriptar(TxtObservaciones_fondo.Text);

                obj1.BusquedaFondo(Txtnombre_fondo,
                                   TxtDireccion_fondo,
                                   TxtObservaciones_fondo,
                                   Txtidfondo);

                Txtnombre_fondo.Text = Seguridad.DesEncriptar(Txtnombre_fondo.Text);
                TxtDireccion_fondo.Text = Seguridad.DesEncriptar(TxtDireccion_fondo.Text);
                TxtObservaciones_fondo.Text = Seguridad.DesEncriptar(TxtObservaciones_fondo.Text);


            }
            MessageBox.Show("Finalizo la Busqueda del idfondo", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Information);
            */
        }

        protected void btnEliminarEdi_Click(object sender, EventArgs e)
        {
            if (TxtidEdificio.Text == "")
            {
                MessageBox.Show("Ingresa primero el IDEdificio ");
            }
            else
            {
                int r = obj1.baja_Edeficio(TxtidEdificio.Text);
                if (r == 1)
                {
                    MessageBox.Show(" Eliminada correctamente.");
                }
                else if (r == 0)
                {
                    MessageBox.Show(" NO Existe!!");
                }
                else
                {
                    MessageBox.Show("Error en la base de datos");
                }
            }
        }

        protected void btnActualizarEdi_Click(object sender, EventArgs e)
        {
            if (TxtidEdificio.Text == "" || TxtDescripcionEdeficio.Text == "")
            {
                MessageBox.Show("llena los datos primero");
            }
            else
            {

                obj1.idEdificio = TxtidEdificio.Text;
               // obj1.DescripcionoEd = Seguridades.Encriptar(TxtDescripcionEdeficio.Text);
                obj1.id_fondo = TextFONDO.Text;

                int r = obj1.actualizar_edificio(TxtidEdificio.Text);
                if (r == -1)
                    MessageBox.Show("Bien!!");
                else
                {
                    MessageBox.Show("Erro en el read");
                }
            }
        }
    }
}