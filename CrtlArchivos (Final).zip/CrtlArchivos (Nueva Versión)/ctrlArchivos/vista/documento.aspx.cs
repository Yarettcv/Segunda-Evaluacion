﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ctrlArchivos.Modelo;
using System.Windows.Forms;

namespace ctrlArchivos.vista
{
    public partial class documento : System.Web.UI.Page
    {
        Documento mi_doc = new Documento(); //from ctrlArchivos.Modelo;
        Expediente miExp = new Expediente();
        Usuario2 obj1 = new Usuario2(); //from metodo
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnAgregarDoc_Click(object sender, EventArgs e)
        {
            mi_doc.clasificacion_exp = ddl_Clasi.Text;
            mi_doc.id_doc = txt_Folio.Text;
            mi_doc.tipo_doc = ddl_Tipo.Text;
            mi_doc.estatus_docu = ddl_Estatus.Text;
            mi_doc.prioridad_doc = ddl_prioridad.Text;
            mi_doc.id_remitente_doc = ddl_Remitente.Text;
            mi_doc.no_doc = txtNum_doc.Text;
            mi_doc.fecha_docu = DateTime.Parse(txt_Fecha_doc.Text);
            mi_doc.id_Destinatario = ddl_Destinatario.Text;
            mi_doc.fecha_rec_doc = DateTime.Parse(txtFecha_Rec_doc.Text);
            mi_doc.hora_rese_doc = DateTime.Parse(txt_Hora_doc.Text);
            mi_doc.asunto = txt_Asunto.Text;
            mi_doc.obs_doc = txt_observaciones.Text;
            mi_doc.des_anexo_doc = txt_Desc.Text;
            mi_doc.no_fajos_doc = int.Parse(txt_fojas.Text);
            mi_doc.id_delegado_doc = ddl_turno.Text;
            mi_doc.estatus_docu = ddl_Estatus_turno.Text;
            mi_doc.fecha_dele_doc = DateTime.Parse(txtFecha_turno.Text);

            int r = mi_doc.Guardar();

            if (r == 1)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "GuardarDatos();", true);
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ErAgregar();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ErAgregar();", true);

        }

        protected void btnActualizarDoc_Click(object sender, EventArgs e)
        {
            mi_doc.clasificacion_exp = ddl_Clasi.Text;
            mi_doc.id_doc = txt_Folio.Text;
            mi_doc.tipo_doc = ddl_Tipo.Text;
            mi_doc.estatus_docu = ddl_Estatus.Text;
            mi_doc.prioridad_doc = ddl_prioridad.Text;
            mi_doc.id_remitente_doc = ddl_Remitente.Text;
            mi_doc.no_doc = txtNum_doc.Text;
            mi_doc.fecha_docu = DateTime.Parse(txt_Fecha_doc.Text);
            mi_doc.id_Destinatario = ddl_Destinatario.Text;
            mi_doc.fecha_rec_doc = DateTime.Parse(txtFecha_Rec_doc.Text);
            mi_doc.hora_rese_doc = DateTime.Parse(txt_Hora_doc.Text);
            mi_doc.asunto = txt_Asunto.Text;
            mi_doc.obs_doc = txt_observaciones.Text;
            mi_doc.des_anexo_doc = txt_Desc.Text;
            mi_doc.no_fajos_doc = int.Parse(txt_fojas.Text);
            mi_doc.id_delegado_doc = ddl_turno.Text;
            mi_doc.estatus_docu = ddl_Estatus_turno.Text;
            mi_doc.fecha_dele_doc = DateTime.Parse(txtFecha_turno.Text);

            int r = mi_doc.Actualizar();

            if (r == 1)
                MessageBox.Show(" El registro se modificio correctamente ;) ");
            else if (r == 0)
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ErAgregar();", true);
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "ErAgregar();", true);
        }

        protected void btnEliminarDoc_Click(object sender, EventArgs e)
        {
            int res = mi_doc.Eliminar(txt_Folio.Text);
            if (res == 1)
                MessageBox.Show(" El registro se elimino! ;) ");
            else
                ClientScript.RegisterStartupScript(GetType(), "mostrar", "msgError('" + "Registro no eliminado" + "');", true);
        }

        protected void btnBuscarDoc_Click(object sender, EventArgs e)
        {
           
            /*bool resp = mi_doc.BuscarDoc(txt_Folio.Text, ref mensaje);
            if (resp)
            {
                mi_doc.BuscarDoc(ddl_Clasi,
                                         txt_Folio,
                                         ddl_Tipo,
                                         ddl_Estatus,
                                         ddl_prioridad,
                                         txtNum_doc,
                                         txt_Fecha_doc,
                                         ddl_Remitente,
                                         ddl_Destinatario,
                                         txtFecha_Rec_doc,
                                         txt_Hora_doc,
                                         txt_Asunto,
                                         txt_observaciones,
                                         txt_Desc,
                                         txt_fojas,
                                         ddl_turno,
                                         ddl_Estatus_turno,
                                         txtFecha_turno);
                btnAgregarDoc.Visible = false;
                btnActualizarDoc.Visible = true;
                btnEliminarDoc.Visible = true;
            }
            else
            {
                ClientScript.RegisterStartupScript(GetType(), "mostar", "msgError('" + mensaje + "');", true);
            }
            */

        }
    }
}
